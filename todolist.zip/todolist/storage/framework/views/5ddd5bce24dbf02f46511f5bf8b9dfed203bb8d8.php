<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.3/font/bootstrap-icons.css">
	<title>Document</title>
</head>
<body>
	<h1>Main</h1>

	<a href="<?php echo e(route("out")); ?>">Log out</a>
	<a href="<?php echo e(route("insertar")); ?>">Insertar tarea</a>
	<a href="<?php echo e(route("gestionEtq")); ?>">Gestionar etiquetas</a>

	<table class="table-auto">
  <thead>
    <tr>
      <th>Titulo</th>
      <th>Fecha</th>
      <th>Completado</th>
      <th>Etiquetas</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($t["titulo"]); ?></td>
			<td><?php echo e($t["fecha"]); ?></td>
			<td>
				<?php if($t["completa"]==1): ?>
					<i class="bi bi-check-lg"></i>
				<?php else: ?>
					<i class="bi bi-x-lg"></i>
				<?php endif; ?>
			</td>
			<td>
				<?php $__currentLoopData = $etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if(isset($item[$t["idtar"]])): ?>
						<p><?php echo e($item[$t["idtar"]]); ?></p>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</td>
			<td>
				<?php if($t["completa"]==0): ?>
					<a href="<?php echo e(route("finalizar",["id"=>$t["idtar"]])); ?>">Finalizar</a>
				<?php endif; ?>
			</td>
			<td>
				<a href="<?php echo e(route("borrar",["id"=>$t["idtar"]])); ?>">Borrar</a>
			</td>
			<td>
				<?php if($t["completa"]==0): ?>
					<a href="<?php echo e(route("edicion",["id"=>$t["idtar"]])); ?>">Editar</a>
				<?php endif; ?>
			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</body>
</html><?php /**PATH C:\xampp\htdocs\todolist\resources\views/tareas/index.blade.php ENDPATH**/ ?>