<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<form action="<?php echo e(route("confActEtq")); ?>" method="post">
		<?php echo csrf_field(); ?>
		<input type="hidden" name="idetq" value="<?php echo e($id); ?>">
		<label for="etiqueta">etiqueta</label>
		<input type="text" name="etiqueta" value="<?php echo e($etiqueta); ?>"> <br>
		<label for="color">color</label>
		<input type="text" name="color" value="<?php echo e($color); ?>"> <br>
		<button>Añadir</button>
	</form>
</body>
</html><?php /**PATH C:\xampp\htdocs\todolist\resources\views/etiquetas/act.blade.php ENDPATH**/ ?>