<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
	<title>Document</title>
</head>
<body>
    <div class="w-full flex justify-end">
        <a class="pr-3" href="<?php echo e(route("indice")); ?>">volver</a>
    </div>
    <h1 class="text-5xl m-3 mb-8">Insertar</h1>

	<form class="m-3" action="<?php echo e(route("confInsert")); ?>" method="post">
		<?php echo csrf_field(); ?>
		<label class="mt-2" for="titulo">Titulo</label>
		<input class="mt-2" type="text" name="titulo"> <br>
		<label class="mt-2" for="texto">Texto</label>
		<input class="mt-2" type="text" name="texto"> <br>
		<select class="ml-10 m-5"name="etiqueta[]" multiple>
			<?php $__currentLoopData = $etq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($item["idetq"]); ?>"><?php echo e($item["etiqueta"]); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
        <br>
		<button class="ml-10">Añadir</button>
	</form>

</body>
</html>
<?php /**PATH F:\Programas\wamp64\www\todolist\resources\views/insertar/index.blade.php ENDPATH**/ ?>