<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<form action="<?php echo e(route("confInsert")); ?>" method="post">
		<?php echo csrf_field(); ?>
		<label for="titulo">Titulo</label>
		<input type="text" name="titulo"> <br>
		<label for="texto">Texto</label> 
		<input type="text" name="texto"> <br>
		<select name="etiqueta[]" multiple>
			<?php $__currentLoopData = $etq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($item["idetq"]); ?>"><?php echo e($item["etiqueta"]); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
		<button>Añadir</button>
	</form>
</body>
</html><?php /**PATH C:\xampp\htdocs\todolist\resources\views/insertar/index.blade.php ENDPATH**/ ?>