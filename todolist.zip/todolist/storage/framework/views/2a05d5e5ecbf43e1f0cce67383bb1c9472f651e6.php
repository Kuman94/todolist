<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<h1>Edicion</h1>
	<form action="<?php echo e(route("actualizarTarea")); ?>" method="post">
		<?php echo csrf_field(); ?>
		<input type="hidden" name="id" value="<?php echo e($id); ?>">
		<label for="titulo">Titulo</label>
		<input type="text" name="titulo" value="<?php echo e($titulo); ?>"> <br>
		<label for="texto">Texto</label> 
		<input type="text" name="texto" value="<?php echo e($texto); ?>"> <br>
		<label for="fecha">Fecha</label> 
		<input type="text" name="fecha" value="<?php echo e($fecha); ?>"> <br>
		<label for="completa">Completa</label> 
		<input type="text" name="completa" value="<?php echo e($completa); ?>"> <br>
		<button>Actualizar</button>
	</form>
</body>	
</html><?php /**PATH C:\xampp\htdocs\todolist\resources\views/edicion/index.blade.php ENDPATH**/ ?>