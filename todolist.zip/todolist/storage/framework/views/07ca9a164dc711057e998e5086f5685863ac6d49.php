<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<h1>Gestion de etiquetas</h1>
	<a href="<?php echo e(route("addEtq")); ?>">Añadir etiquetas</a>
	<table class="table-auto">
  <thead>
    <tr>
      <th>etiqueta</th>
      <th>color</th>
    </tr>
  </thead>
  <tbody>
  	<?php
      $contador=0;
  	?>
    <?php $__currentLoopData = $etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($t["etiqueta"]); ?></td>
			<td><?php echo e($t["color"]); ?></td>
			<?php if($tareasAs[$contador][$t["idetq"]]==false): ?>
              <td>
              	<a href="<?php echo e(route("borrarEtq",["idetq"=>$t["idetq"]])); ?>">Borrar</a>
              	<a href="<?php echo e(route("actualizarEtq",["idetq"=>$t["idetq"]])); ?>">Actualizar</a>
              </td>
			<?php endif; ?>
		</tr>
		<?php
		  $contador++;
		?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</body>
</html><?php /**PATH C:\xampp\htdocs\todolist\resources\views/etiquetas/index.blade.php ENDPATH**/ ?>