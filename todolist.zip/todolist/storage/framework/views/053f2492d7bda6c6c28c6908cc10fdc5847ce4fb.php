<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
	<title>Document</title>
</head>
<body>
	<h1 class="text-5xl m-10">Gestion de etiquetas</h1>
    <div class="w-full m-5 ml-12 gap-3">
        <a href="<?php echo e(route("addEtq")); ?>">Añadir etiquetas</a>
        |
        <a href="<?php echo e(route("indice")); ?>">volver</a>
    </div>
	<table class="w-2/5 text-center table-fixed mt-10 ">
  <thead>
    <tr>
      <th>etiqueta</th>
      <th>color</th>
    </tr>
  </thead>
  <tbody>
  	<?php
      $contador=0;
  	?>
    <?php $__currentLoopData = $etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($t["etiqueta"]); ?></td>
			<td><?php echo e($t["color"]); ?></td>
			<?php if($tareasAs[$contador][$t["idetq"]]==false): ?>
              <td>
              	<a class="m-1 bg-rose-500 p-0.5" href="<?php echo e(route("borrarEtq",["idetq"=>$t["idetq"]])); ?>">Borrar</a>
              	<a class="m-1 bg-blue-300 p-0.5" href="<?php echo e(route("actualizarEtq",["idetq"=>$t["idetq"]])); ?>">Actualizar</a>
              </td>
			<?php endif; ?>
		</tr>
		<?php
		  $contador++;
		?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</body>
</html>
<?php /**PATH F:\Programas\wamp64\www\todolist\resources\views/etiquetas/index.blade.php ENDPATH**/ ?>