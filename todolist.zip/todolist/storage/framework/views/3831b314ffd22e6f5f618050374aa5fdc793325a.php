<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<form action="<?php echo e(route("confAddEtq")); ?>" method="post">
		<?php echo csrf_field(); ?>
		<label for="etiqueta">etiqueta</label>
		<input type="text" name="etiqueta"> <br>
		<label for="color">color</label>
		<input type="text" name="color"> <br>
		<button>Añadir</button>
	</form>
</body>
</html><?php /**PATH C:\xampp\htdocs\todolist\resources\views/etiquetas/add.blade.php ENDPATH**/ ?>