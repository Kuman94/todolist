<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\tareaController;
use App\Http\Controllers\etiquetaController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [tareaController::class,"index"])->middleware(['auth'])->name("indice");

Route::get("finalizar",[tareaController::class,"finalizar"])->name("finalizar");

Route::get("borrar",[tareaController::class,"borrar"])->name("borrar");

Route::get("edicion",[tareaController::class,"edicion"])->name("edicion");

Route::post("actualizarTarea",[tareaController::class,"confEdi"])->name("actualizarTarea");

Route::get("insertar",[tareaController::class,"insertar"])->name("insertar");

Route::post("confInsert",[tareaController::class,"confInsert"])->name("confInsert");

Route::get("gestionEtq",[etiquetaController::class,"index"])->name("gestionEtq");

Route::get("addEtq",[etiquetaController::class,"addEtq"])->name("addEtq");

Route::post("confAddEtq",[etiquetaController::class,"confAddEtq"])->name("confAddEtq");

Route::get("borrarEtq",[etiquetaController::class,"borrarEtq"])->name("borrarEtq");

Route::get("actualizarEtq",[etiquetaController::class,"actualizarEtq"])->name("actualizarEtq");

Route::post("confActEtq",[etiquetaController::class,"confActEtq"])->name("confActEtq");

Route::get("out",function() {
     Auth::logout();
     return redirect()->route("login");
})->middleware(["auth"])->name("out");

require __DIR__.'/auth.php';
