<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tarea', function (Blueprint $table) {
            $table->increments("idtar");
            $table->string("titulo",255);
            $table->string("texto",255);
            $table->date("fecha");
            $table->boolean("completa")->default(false);
            $table->unsignedInteger("idusu");
        });

        Schema::table("tarea",function($table) {
            $table->foreign("idusu")->references("idusu")->on("usuario")->onDelete("cascade");
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tarea');
    }
};
