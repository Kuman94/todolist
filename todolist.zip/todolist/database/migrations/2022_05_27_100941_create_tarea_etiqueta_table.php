<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tarea_etiqueta', function (Blueprint $table) {
            $table->unsignedInteger("idtar");
            $table->unsignedInteger("idetq");

        });

         Schema::table("tarea_etiqueta",function($table) {
            $table->foreign("idtar")->references("idtar")->on("tarea")->onDelete("cascade");
            $table->foreign("idetq")->references("idetq")->on("etiqueta")->onDelete("cascade");
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tarea_etiqueta');
    }
};
