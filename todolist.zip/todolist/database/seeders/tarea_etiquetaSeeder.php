<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Faker\Factory as Faker;

class tarea_etiquetaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
         $faker=Faker::create();
        for($i=0;$i<3;$i++) {
            DB::table("tarea_etiqueta")->insert([
                "idtar"=>$faker->numberBetween(1,10),
                "idetq"=>$faker->numberBetween(1,10),
            ]);
        }
    }
}
