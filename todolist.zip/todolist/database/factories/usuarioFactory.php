<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\usuario>
 */
class usuarioFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            "idusu"=>$this->faker->unique()->numberBetween(1,10),
            "email"=>$this->faker->email(),
            "password"=>Hash::make(12),
            "nombre"=>$this->faker->name(),
            "apellidos"=>$this->faker->name(),
        ];
    }
}
