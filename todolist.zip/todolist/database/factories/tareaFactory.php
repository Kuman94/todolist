<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\tarea>
 */
class tareaFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            "idtar"=>$this->faker->unique()->numberBetween(1,10),
            "titulo"=>$this->faker->name(),
            "texto"=>$this->faker->name(),
            "fecha"=>$this->faker->date($format="Y-m-d",$max="now"),
            "completa"=>$this->faker->boolean(),
            "idusu"=>$this->faker->numberBetween(1,10),
        ];
    }
}
