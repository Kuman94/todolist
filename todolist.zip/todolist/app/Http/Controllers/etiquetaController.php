<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\usuario;
use App\Models\tarea;
use App\Models\etiqueta;
use Illuminate\Support\Facades\Auth;

class etiquetaController extends Controller
{
    public function index() {
         $t=etiqueta::all();
         $tareasAs=[];

         foreach($t as $item) {
            if(sizeof($item->tareas()->get())==0) {
                 $p=[$item["idetq"] => false];
                array_push($tareasAs, $p);
            } else {
                 $p=[$item["idetq"] => true];
                array_push($tareasAs, $p);
            }
         }

        return view("etiquetas/index",["etiquetas"=>$t,"tareasAs"=>$tareasAs]);
    }

    public function addEtq() {
        return view("etiquetas/add");
    }

    public function confAddEtq(Request $req) {
        $etq=new etiqueta;
        $etq->etiqueta=$req->input("etiqueta");
        $etq->color=$req->input("color");
        $etq->save();

        return redirect()->route("gestionEtq");
    }

    public function borrarEtq(Request $req) {
        $t=etiqueta::find($req->input("idetq"))->delete();


        return redirect()->route("gestionEtq");


    }

    public function actualizarEtq(Request $req) {
        $etq=etiqueta::find(intval($req->input("idetq")));
        $etiqueta=$etq["etiqueta"];
        $color=$etq["color"];

        return view("etiquetas/act",["id"=>$req->input("idetq"),"etiqueta"=>$etiqueta,"color"=>$color]);
    }

    public function confActEtq(Request $req) {
        $etq=etiqueta::find($req->input("idetq"));
        $etq->etiqueta=$req->input("etiqueta");
        $etq->color=$req->input("color");
        $etq->save();
        return redirect()->route("gestionEtq");
    }
}
