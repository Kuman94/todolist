<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\usuario;
use App\Models\tarea;
use App\Models\etiqueta;
use Illuminate\Support\Facades\Auth;

class tareaController extends Controller
{
    public function index() {
        $user=usuario::find(Auth::user()->idusu);
        $tareas=$user->tareas();
        $etqLocal=[];
        $etq=[];

        foreach($tareas as $item) {
            $t=tarea::find(intval($item["idtar"]));
            $l=$t->etiquetas()->get();

            foreach($l as $local) {
                $p=[$t["idtar"] => $local["etiqueta"]];
                array_push($etq,$p);
            }
        }

        return view("tareas/index",["tareas"=>$tareas,"etiquetas"=>$etq]);
    }

    public function finalizar(Request $req) {
        $t=tarea::find(intval($req->input("id")));
        $t->completa=1;
        $t->save();
        return redirect()->route("indice");
    }

    public function borrar(Request $req) {
        $t=tarea::find(intval($req->input("id")));
        $t->delete();
        return redirect()->route("indice");
    }

    public function edicion(Request $req) {
        $tarea=tarea::find($req->input("id"));

        return view("edicion/index",["titulo"=>$tarea["titulo"],"texto"=>$tarea["texto"],"fecha"=>$tarea["fecha"],"completa"=>$tarea["completa"],"id"=>$req->input("id")]);
    }

    public function confEdi(Request $req) {
        $tarea=tarea::find($req->input("id"));
        $tarea->titulo=$req->input("titulo");
        $tarea->texto=$req->input("texto");
        $tarea->fecha=$req->input("fecha");
        $tarea->completa=$req->input("completa");
        $tarea->save();
        return redirect()->route("indice");
    }

    public function insertar() {
        $t=etiqueta::all();
        return view("insertar/index",["etq"=>$t]);
    }

    public function confInsert(Request $req) {
        $hoy = getdate();
        $hoy=$hoy["year"]."-".$hoy["mon"]."-".$hoy["mday"];
        $tarea=new tarea;
        $tarea->titulo=$req->input("titulo");
        $tarea->texto=$req->input("texto");
        $tarea->fecha=$hoy;
        $tarea->completa=0;
        $tarea->idusu=Auth::user()->idusu;
        $tarea->save();

        foreach($req->input("etiqueta") as $item) {
            $tarea=tarea::find($tarea->idtar);
            $tarea->etiquetas()->attach($item);
        }
        return redirect()->route("indice");
    }
}

