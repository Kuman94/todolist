<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Auth\Authenticatable;



class usuario extends Model implements AuthenticatableContract
{
    use HasFactory,Authenticatable;

    protected $table="usuario";
    protected $primaryKey="idusu";
    public $timestamps=false;

     public function tareas() {
        return $this->hasMany('App\Models\tarea',"idusu","idusu")->get();
    }

}
