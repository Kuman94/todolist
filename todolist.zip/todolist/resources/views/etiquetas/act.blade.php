<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<form action="{{route("confActEtq")}}" method="post">
		@csrf
		<input type="hidden" name="idetq" value="{{$id}}">
		<label for="etiqueta">etiqueta</label>
		<input type="text" name="etiqueta" value="{{$etiqueta}}"> <br>
		<label for="color">color</label>
		<input type="text" name="color" value="{{$color}}"> <br>
		<button>Añadir</button>
	</form>
</body>
</html>