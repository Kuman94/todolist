<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{asset('css/app.css')}}">
	<title>Document</title>
</head>
<body>
	<h1 class="text-5xl m-10">Gestion de etiquetas</h1>
    <div class="w-full m-5 ml-12 gap-3">
        <a href="{{route("addEtq")}}">Añadir etiquetas</a>
        |
        <a href="{{ route("indice") }}">volver</a>
    </div>
	<table class="w-2/5 text-center table-fixed mt-10 ">
  <thead>
    <tr>
      <th>etiqueta</th>
      <th>color</th>
    </tr>
  </thead>
  <tbody>
  	@php
      $contador=0;
  	@endphp
    @foreach($etiquetas as $t)
		<tr>
			<td>{{$t["etiqueta"]}}</td>
			<td>{{$t["color"]}}</td>
			@if($tareasAs[$contador][$t["idetq"]]==false)
              <td>
              	<a class="m-1 bg-rose-500 p-0.5" href="{{route("borrarEtq",["idetq"=>$t["idetq"]])}}">Borrar</a>
              	<a class="m-1 bg-blue-300 p-0.5" href="{{route("actualizarEtq",["idetq"=>$t["idetq"]])}}">Actualizar</a>
              </td>
			@endif
		</tr>
		@php
		  $contador++;
		@endphp
	@endforeach
  </tbody>
</table>
</body>
</html>
