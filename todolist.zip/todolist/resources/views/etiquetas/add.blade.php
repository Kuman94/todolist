<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{asset('css/app.css')}}">
	<title>Document</title>
</head>
<body>
    <button class="w-full mr-3 flex justify-end">
        <a class="pr-3" href="{{ route("indice") }}">volver</a>
    </button>

	<h1 class="text-5xl m-3 mb-10">Añadir etiquetas</h1>
	<form class="m-3" action="{{route("confAddEtq")}}" method="post">
		@csrf
		<label class="mt-2" for="etiqueta">etiqueta</label>
		<input class="mt-2"type="text" name="etiqueta"> <br>
		<label class="mt-2" for="color">color</label>
		<input class="mt-2" type="text" name="color"> <br>
		<button class="mt-6 ml-10">Añadir</button>
	</form>


</body>
</html>
