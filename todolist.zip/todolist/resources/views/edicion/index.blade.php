<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<h1>Edicion</h1>
	<form action="{{ route("actualizarTarea") }}" method="post">
		@csrf
		<input type="hidden" name="id" value="{{$id}}">
		<label for="titulo">Titulo</label>
		<input type="text" name="titulo" value="{{$titulo}}"> <br>
		<label for="texto">Texto</label> 
		<input type="text" name="texto" value="{{$texto}}"> <br>
		<label for="fecha">Fecha</label> 
		<input type="text" name="fecha" value="{{$fecha}}"> <br>
		<label for="completa">Completa</label> 
		<input type="text" name="completa" value="{{$completa}}"> <br>
		<button>Actualizar</button>
	</form>
</body>	
</html>