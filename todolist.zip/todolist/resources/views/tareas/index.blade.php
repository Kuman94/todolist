<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="{{asset('css/app.css')}}">
	<title>Document</title>
</head>
<body>
    <div class="w-full mr-3 flex justify-end">
        <a class="pr-3" href="{{route("out")}}">Log out</a>
    </div>

	<h1 class="text-5xl m-3">Main</h1>

     <div class="w-full flex justify-center m-3 gap-3">
        <a class="" href="{{route("insertar")}}">Insertar tarea</a>
        |
	    <a href="{{route("gestionEtq")}}">Gestionar etiquetas</a>
     </div>


	<table class="w-full text-center table-fixed mt-10">
  <thead >
    <tr>
      <th>Titulo</th>
      <th>Fecha</th>
      <th>Completado</th>
      <th>Etiquetas</th>
    </tr>
  </thead>
  <tbody>
    @foreach($tareas as $t)
		<tr>
			<td>{{$t["titulo"]}}</td>
			<td>{{$t["fecha"]}}</td>
			<td>
				@if($t["completa"]==1)
					<i class="bi bi-check-lg"></i>
				@else
					<i class="bi bi-x-lg"></i>
				@endif
			</td>
			<td>
				@foreach($etiquetas as $item)
					@isset($item[$t["idtar"]])
						<p>{{$item[$t["idtar"]]}}</p>
					@endisset
				@endforeach
			</td>
			<td>
				@if($t["completa"]==0)
					<a class="bg-lime-300 p-0.5" href="{{route("finalizar",["id"=>$t["idtar"]])}}">Finalizar</a>
				@endisset
			</td>
			<td>
				<a class="bg-rose-500 p-0.5" href="{{route("borrar",["id"=>$t["idtar"]])}}">Borrar</a>
			</td>
			<td>
				@if($t["completa"]==0)
					<a class="bg-amber-300	p-0.5" href="{{route("edicion",["id"=>$t["idtar"]])}}">Editar</a>
				@endisset
			</td>
		</tr>
	@endforeach
  </tbody>
</table>
</body>
</html>
