<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{asset('css/app.css')}}">
	<title>Document</title>
</head>
<body>
    <div class="w-full flex justify-end">
        <a class="pr-3" href="{{ route("indice") }}">volver</a>
    </div>
    <h1 class="text-5xl m-3 mb-8">Insertar</h1>

	<form class="m-3" action="{{ route("confInsert") }}" method="post">
		@csrf
		<label class="mt-2" for="titulo">Titulo</label>
		<input class="mt-2" type="text" name="titulo"> <br>
		<label class="mt-2" for="texto">Texto</label>
		<input class="mt-2" type="text" name="texto"> <br>
		<select class="ml-10 m-5"name="etiqueta[]" multiple>
			@foreach($etq as $item)
				<option value="{{$item["idetq"]}}">{{$item["etiqueta"]}}</option>
			@endforeach
		</select>
        <br>
		<button class="ml-10">Añadir</button>
	</form>

</body>
</html>
